import { Component } from '@angular/core';

@Component({
    template: `
    <h2>Lazy Component</h2>
    `
})
export class LazyComponent {}