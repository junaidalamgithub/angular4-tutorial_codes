import { Component } from '@angular/core';

@Component({
    template: `<div style="width:350px;height:200px;background-color:#ffff00">
    <h1>This is Home Page</h1></div>`
})
export class HomeComponent{}