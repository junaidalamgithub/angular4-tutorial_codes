<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 

$inputKeyWord = "ALL";
if(isset($_GET["inputKeyWord"])) {
$inputKeyWord = $_GET["inputKeyWord"];
}

include 'Classes/PHPExcel/IOFactory.php';

$inputFileName = 'au-towns-sample.xlsx';

//  Read your Excel workbook
try {
    $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
    $objReader = PHPExcel_IOFactory::createReader($inputFileType);
    $objPHPExcel = $objReader->load($inputFileName);
} catch (Exception $e) {
    die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) 
    . '": ' . $e->getMessage());
}

//  Get worksheet dimensions
$sheet = $objPHPExcel->getSheet(0);
$highestRow = $sheet->getHighestRow();
$highestColumn = $sheet->getHighestColumn();

//  Loop through each row of the worksheet in turn
$str1 ="";
for ($row = 2; $row <= $highestRow; $row++) {
    //  Read a row of data into an array
    $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, 
    NULL, TRUE, FALSE);
	
	$suburb = $rowData[0][1];
	if ( strpos($suburb, $inputKeyWord) !== false || $inputKeyWord == "ALL") {
	$str="";
	    for( $i = 0; $i<sizeof($rowData[0]); $i++ ) {
		
		
			$word = $rowData[0][$i];

		if($word==""){
		$word = "EMPTY";
		}
		$str = $str . "~" . $word;
   
         }
		 $str1 = $str1."|". $suburb .'-'.$str;

		}
}
 $result = array();
$lines  = explode("|", $str1);

foreach ($lines as $line) {
    $line = explode('-', $line);
    $result[array_shift($line)] = array_shift($line);
}
 echo json_encode($result);
?>