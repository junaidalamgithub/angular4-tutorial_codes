import { Component, ElementRef, AfterViewInit } from '@angular/core';
import { AutoCompleteService } from './services/autocomplete.service';


@Component({
  selector: 'my-own',
  templateUrl:'./app.component.html',
  styles:[`
  .spinner{
    position:absolute;
  opacity: 0.5;
    z-index:1000;
    margin-left: 50%;
    margin-top:20%;
  }
  `],
  providers: [AutoCompleteService]
})
export class AppComponent implements AfterViewInit {
public title: string = 'Angular Forms';
public suburbs = [];
private fullData: any;

constructor( private autoCompleteService: AutoCompleteService, private elem: ElementRef) {}

public keyWord: string ='ALL';
public onkeyup(): void {
 // this.elem.nativeElement.querySelector('#spinner').style.visibility = 'visible';
// this.autoCompleteService.getAutoSuggestTexts (this.keyWord).subscribe(res=>this.extractAutoSuggestData(res.json()));
}

ngAfterViewInit():void {
  this.elem.nativeElement.querySelector('#spinner').style.visibility = 'visible';
 this.autoCompleteService.getAutoSuggestTexts (this.keyWord).subscribe(res=>this.extractAutoSuggestData(res.json()));
}

private extractAutoSuggestData(data: any): void {
  this.fullData = data;
  let suburbKeys = Object.keys(data);
  let itemCount: number = suburbKeys.length;
  for (let i=0 ; i<itemCount; i++) {
this.suburbs.push(suburbKeys[i]);
//console.log('data key: ',Object.keys(data));
  }
 // console.log('suburbs', this.suburbs);
  this.elem.nativeElement.querySelector('#spinner').style.visibility = 'hidden';
}
  public selectItem(event: any): void {
   // console.log(this.fullData[event.target.value]);
    let vals = this.fullData[event.target.value];
    let valsArray = vals.split("~");
    this.elem.nativeElement.querySelector('#state').value=valsArray[5];
    this.elem.nativeElement.querySelector('#type').value=valsArray[7];
  }

  public getData(data: any): void {
     this.elem.nativeElement.querySelector('#state').value=data.stateValue;
    this.elem.nativeElement.querySelector('#type').value=data.typeValue;
  }



}
