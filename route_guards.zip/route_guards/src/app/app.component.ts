import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'my-own',
  templateUrl:'./app.component.html'
})
export class AppComponent  {
public title: string = 'Angular Routing Guard';

constructor(private router: Router) {

}

public gotoJava(): void {
  this.router.navigate(['/java']);
}

public gotoAndroid(): void {
  this.router.navigate(['/android']);
}

}
