import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './views/home.component';
import { JavaComponent } from './views/java.component';
import { JavaSwingComponent } from './views/java.swing.component';
import { JavaSpringComponent } from './views/java.spring.component';
import { AndroidComponent } from './views/android.component';
import { AndroidIDEComponent } from './views/android.ide.component';
import { RouterModule } from '@angular/router';
import { approutes } from './app.route';
import { CheckGuard } from './router-guards/check-guard';
import { DetailComponent } from './custom-component/details.component';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    JavaComponent,
    JavaSwingComponent,
    JavaSpringComponent,
    AndroidComponent,
    AndroidIDEComponent,
    DetailComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(approutes)
    
  ],
  providers: [CheckGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
